"use client";

import { useState } from "react";
import { PART_MAKES, PART_TYPES } from "@/lib/spare-parts-options";

const [customPartType, setCustomPartType] = useState("");
const [customPartSubtype, setCustomPartSubtype] = useState("");

export function StyledSelect({
  id,
  name,
  label,
  value,
  options,
  placeholder,
  disabled,
  onChange,
}: {
  id: string;
  name: string;
  label: string;
  value: string;
  options: string[];
  placeholder: string;
  disabled?: boolean;
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const style = { borderRadius: "8px", fontSize: "13px", minHeight: "42px" };
  return (
    <div className="position-relative">
      <label
        htmlFor={id}
        className="form-label text-secondary small fw-semibold mb-1"
      >
        {label}
      </label>
      <input
        type="hidden"
        id={id}
        name={name}
        value={value}
        required={!disabled}
      />
      <button
        type="button"
        id={`${id}-button`}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        className="form-select w-100 text-start px-3 py-2 border-light-subtle text-secondary"
        style={{ ...style, backgroundColor: "#fff" }}
      >
        {value || placeholder}
      </button>
      {open && !disabled && (
        <div
          role="listbox"
          aria-label={label}
          className="position-absolute start-0 end-0 bg-white border shadow-sm p-2"
          style={{
            top: "100%",
            zIndex: 1100,
            borderRadius: "8px",
            maxHeight: "220px",
            overflowY: "auto",
          }}
        >
          {options.map((option) => (
            <button
              type="button"
              role="option"
              aria-selected={value === option}
              key={option}
              onClick={() => {
                onChange(option);
                setOpen(false);
              }}
              className={`btn w-100 text-start px-3 py-2 border-0 ${value === option ? "bg-light text-dark fw-semibold" : "bg-white text-secondary"}`}
              style={{ borderRadius: "6px", fontSize: "13px" }}
            >
              {option}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function SparePartsFields() {
  const [make, setMake] = useState("");
  const [model, setModel] = useState("");
  const [partType, setPartType] = useState("");
  const [subtype, setSubtype] = useState("");
  const style = { borderRadius: "8px", fontSize: "13px", minHeight: "42px" };
  const labelClass = "form-label text-secondary small fw-semibold mb-1";

  return (
    <section
      className="mb-4 p-4 border border-light-subtle"
      style={{ borderRadius: "20px", backgroundColor: "#f8fafc" }}
      aria-labelledby="spares-heading"
    >
      <h5 id="spares-heading" className="h6 fw-bold mb-3 text-dark">
        Spares &amp; Car Care Details
      </h5>
      <div className="row g-3">
        <div className="col-12 col-md-6">
          <StyledSelect
            id="part-make"
            name="partMake"
            label="Vehicle Make"
            value={make}
            options={PART_MAKES}
            placeholder="Select Make"
            onChange={(value) => {
              setMake(value);
              setModel("");
            }}
          />
        </div>
        <div className="col-12 col-md-6">
          <label htmlFor="part-model" className={labelClass}>
            Vehicle Model
          </label>
          <input
            id="part-model"
            name="partModel"
            required
            disabled={!make}
            maxLength={100}
            value={model}
            onChange={(e) => setModel(e.target.value)}
            placeholder="e.g. Camry, or Other Model"
            className="form-control px-3 py-2 border-light-subtle"
            style={style}
          />
        </div>
        <div className="col-12 col-md-6">
          <StyledSelect
            id="part-type"
            name="partType"
            label="Part Type"
            value={partType}
            options={Object.keys(PART_TYPES)}
            placeholder="Select Part Type"
            onChange={(value) => {
              setPartType(value);
              setSubtype("");
            }}
          />
        </div>
        <div className="col-12 col-md-6">
          <StyledSelect
            id="part-subtype"
            name="partSubtype"
            label="Part Subtype"
            value={subtype}
            options={PART_TYPES[partType] || []}
            placeholder="Select Part Subtype"
            disabled={!partType}
            onChange={setSubtype}
          />
        </div>
      </div>
    </section>
  );
}

"use client";

import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { NIGERIA_LOCATIONS } from "@/lib/nigeriaLocations";

import { SparePartsFields, StyledSelect } from "@/components/SparePartsFields";

type Category = { id: string; name: string };

export function PostAdForm({ categories }: { categories: Category[] }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const [condition, setCondition] = useState("");

  // ⚡ MASTER GATEWAY STATE CONTROLLERS
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(
    null,
  );
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>("");
  const [selectedState, setSelectedState] = useState<string>("");
  const [selectedLga, setSelectedLga] = useState<string>("");
  const [activeMenu, setActiveMenu] = useState<"category" | "location" | "">(
    "",
  );

  // ⚡ DYNAMIC AUTOMOBILE DETAILED STATE CONTROLLERS
  const [carBrand, setCarBrand] = useState<string>("");
  const [customBrand, setCustomBrand] = useState<string>("");
  const [carModel, setCarModel] = useState<string>("");
  const [carYear, setCarYear] = useState<string>("");
  const [carMileage, setCarMileage] = useState<string>("");
  const [carVin, setCarVin] = useState<string>("");
  const [carTransmission, setCarTransmission] = useState<string>("");
  const [carFuel, setCarFuel] = useState<string>("");
  const [carCylinders, setCarCylinders] = useState<string>("");
  const [carInterior, setCarInterior] = useState<string>("");
  const [carColor, setCarColor] = useState<string>("");
  const [carFeatures, setCarFeatures] = useState<string[]>([]);
  const [carAvailableForSwap, setCarAvailableForSwap] = useState<string>("");

  // 💡 MULTI-SELECT CHECKLIST MANAGER FOR KEY FEATURES
  const toggleFeature = (featureId: string) => {
    if (carFeatures.includes(featureId)) {
      setCarFeatures(carFeatures.filter((f) => f !== featureId));
    } else {
      setCarFeatures([...carFeatures, featureId]);
    }
  };

  // DYNAMIC SUB-CATEGORIES BASED ON SELECTED ROOT CATEGORY
  let subCategories: string[] = ["General Specifications", "Standard Variant"];
  if (selectedCategory?.name.toLowerCase().includes("vehic")) {
    subCategories = [
      "Automobiles",
      "Spares & Car Care",
      "Bikes, Scooters & E-Mobility",
      "Buses & Commercial Vans",
      "Haulage Trucks & Trailers",
      "Heavy Duty & Plant Machinery",
      "Marine Vessels & Boats",
    ];
  }

  // DATABASE SUBMIT CONTROLLER
  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setPending(true);
    const form = new FormData(e.currentTarget);
    const completeLocation = `${selectedState}, ${selectedLga}`;
    const imageFiles = form
      .getAll("images")
      .filter(
        (value): value is File => value instanceof File && value.size > 0,
      );
    if (imageFiles.length < 3 || imageFiles.length > 10) {
      setError("Please upload between 3 and 10 images.");
      setPending(false);
      return;
    }
    const imageData = await Promise.all(
      imageFiles.map(
        (file) =>
          new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = () => reject(new Error("Could not read image"));
            reader.readAsDataURL(file);
          }),
      ),
    );

    try {
      const res = await fetch("/api/listings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: form.get("title"),
          description: form.get("description"),
          price: Number(form.get("price")),
          location: completeLocation,
          condition: form.get("condition"),
          imageUrl: JSON.stringify(imageData),
          categoryId: selectedCategory?.id,
          subcategory: selectedSubCategory,
          spareDetails:
            selectedSubCategory === "Spares & Car Care"
              ? {
                  make: form.get("partMake"),
                  model: form.get("partModel"),
                  type: form.get("partType"),
                  subtype: form.get("partSubtype"),
                }
              : null,
          // BUNDLED AUTOMOBILE SPECIFICATIONS PAYLOAD
          metadata:
            selectedSubCategory === "Automobiles"
              ? {
                  brand: carBrand === "Other" ? customBrand : carBrand,
                  model: carModel,
                  year: carYear,
                  mileage: Number(carMileage),
                  vin: carVin,
                  transmission: carTransmission,
                  fuel: carFuel,
                  cylinders: carCylinders,
                  interior: carInterior,
                  color: carColor,
                  features: carFeatures,
                  availableForSwap: carAvailableForSwap === "YES",
                }
              : null,
        }),
      });

      setPending(false);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Could not post ad");
        return;
      }
      const listing = await res.json();
      router.push(`/listing/${listing.id}`);
      router.refresh();
    } catch {
      setError("Could not post ad. Check your connection and try again.");
    } finally {
      setPending(false);
    }
  }

  const isGatewayUnlocked =
    selectedCategory && selectedSubCategory && selectedState && selectedLga;
  return (
    <form onSubmit={onSubmit} className="w-100 mt-3">
      <div className="row g-4">
        <div className="col-12 col-lg-8">
          <div
            className="card border-0 shadow-sm p-4 mb-4"
            style={{ borderRadius: "24px", backgroundColor: "#ffffff" }}
          >
            {/* ROW 1: CATEGORIES & SUB-CATEGORY ROW */}
            <div className="position-relative mb-3">
              <div className="row g-3">
                <div
                  className="col-12 col-md-6"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    setSelectedCategory(null);
                    setSelectedSubCategory("");
                    setActiveMenu(
                      activeMenu === "category" && !selectedCategory
                        ? ""
                        : "category",
                    );
                  }}
                >
                  <label className="form-label text-secondary small fw-semibold mb-1">
                    Category
                  </label>
                  <div
                    className="form-select px-3 py-2.5 border-light-subtle text-secondary d-flex align-items-center"
                    style={{ borderRadius: "12px", fontSize: "14px" }}
                  >
                    {selectedCategory
                      ? selectedCategory.name
                      : "Select Category"}
                  </div>
                </div>

                <div
                  className="col-12 col-md-6"
                  style={{
                    cursor: selectedCategory ? "pointer" : "not-allowed",
                    opacity: selectedCategory ? 1 : 0.6,
                  }}
                  onClick={() => {
                    if (selectedCategory) {
                      setActiveMenu(
                        activeMenu === "category" && selectedCategory
                          ? ""
                          : "category",
                      );
                    }
                  }}
                >
                  <label className="form-label text-secondary small fw-semibold mb-1">
                    Sub-Category
                  </label>
                  <div
                    className="form-select px-3 py-2.5 border-light-subtle text-secondary d-flex align-items-center"
                    style={{ borderRadius: "12px", fontSize: "14px" }}
                  >
                    {selectedSubCategory || "Select Sub-Category"}
                  </div>
                </div>
              </div>

              {activeMenu === "category" && (
                <div
                  className="position-absolute start-0 top-100 w-100 bg-white border shadow-sm p-4 mt-2"
                  style={{ borderRadius: "20px", zIndex: 99 }}
                >
                  <div className="d-flex align-items-start justify-content-between mb-3">
                    <div>
                      <h4
                        className="h6 fw-bold mb-1"
                        style={{ color: "#0f172a" }}
                      >
                        {!selectedCategory
                          ? "Choose a Category"
                          : "Choose a Sub-Category"}
                      </h4>
                      {selectedCategory && (
                        <button
                          type="button"
                          className="btn btn-link p-0 text-decoration-none small text-success fw-semibold"
                          style={{ fontSize: "12px" }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCategory(null);
                            setSelectedSubCategory("");
                          }}
                        >
                          ← Back to Main Categories
                        </button>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenu("");
                      }}
                      className="btn border-0 p-1 text-secondary lh-1"
                      style={{ fontSize: "18px" }}
                    >
                      ✕
                    </button>
                  </div>

                  <div className="row g-3">
                    {!selectedCategory
                      ? categories.map((c) => {
                          let bgCardColor = "#f1f5f9";
                          let graphicAsset = "📁";
                          const nameCheck = c.name.toLowerCase();
                          if (nameCheck.includes("agric")) {
                            bgCardColor = "#e8f5e9";
                            graphicAsset = "🌾";
                          } else if (nameCheck.includes("beauty")) {
                            bgCardColor = "#e3f2fd";
                            graphicAsset = "💄";
                          } else if (nameCheck.includes("elect")) {
                            bgCardColor = "#fff3e0";
                            graphicAsset = "📺";
                          } else if (nameCheck.includes("fash")) {
                            bgCardColor = "#f3e5f5";
                            graphicAsset = "👗";
                          } else if (nameCheck.includes("home")) {
                            bgCardColor = "#efebe9";
                            graphicAsset = "🛋️";
                          } else if (nameCheck.includes("phone")) {
                            bgCardColor = "#fafafa";
                            graphicAsset = "📱";
                          } else if (nameCheck.includes("prop")) {
                            bgCardColor = "#e8eaf6";
                            graphicAsset = "🏠";
                          } else if (nameCheck.includes("vehic")) {
                            bgCardColor = "#efe5fd";
                            graphicAsset = "🚗";
                          }

                          return (
                            <div key={c.id} className="col-6 col-md-3">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCategory(c);
                                  setSelectedSubCategory("");
                                }}
                                className="btn w-100 d-flex flex-column align-items-center justify-content-center text-center p-3 border-0 transition-all"
                                style={{
                                  backgroundColor: bgCardColor,
                                  borderRadius: "16px",
                                  minHeight: "105px",
                                }}
                              >
                                <span
                                  className="mb-2 d-block"
                                  style={{ fontSize: "26px" }}
                                >
                                  {graphicAsset}
                                </span>
                                <span
                                  className="fw-medium text-dark text-wrap px-1"
                                  style={{
                                    fontSize: "12px",
                                    lineHeight: "1.3",
                                  }}
                                >
                                  {c.name}
                                </span>
                              </button>
                            </div>
                          );
                        })
                      : subCategories.map((sub) => {
                          let leftEmoji = "🔹";
                          const parentName =
                            selectedCategory.name.toLowerCase();
                          if (parentName.includes("phone")) leftEmoji = "📱";
                          else if (parentName.includes("fash"))
                            leftEmoji = "👗";
                          else if (parentName.includes("elect"))
                            leftEmoji = "💻";
                          else if (parentName.includes("vehic"))
                            leftEmoji = "🚗";
                          else if (parentName.includes("prop"))
                            leftEmoji = "🏢";

                          return (
                            <div key={sub} className="col-12 col-sm-6 col-md-4">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedSubCategory(sub);
                                  setActiveMenu("");
                                }}
                                className="btn w-100 d-flex align-items-center bg-white border border-light-subtle text-start py-2 px-3 transition-all"
                                style={{
                                  borderRadius: "8px",
                                  boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                                  height: "64px",
                                }}
                              >
                                <span
                                  className="me-2 flex-shrink-0"
                                  style={{ fontSize: "16px" }}
                                >
                                  {leftEmoji}
                                </span>
                                <span
                                  className="text-dark text-wrap fw-medium"
                                  style={{ fontSize: "13px" }}
                                >
                                  {sub}
                                </span>
                              </button>
                            </div>
                          );
                        })}
                  </div>
                </div>
              )}
            </div>
            {/* ROW 2: GEOGRAPHY REGIONAL LOCATIONS */}
            <div className="position-relative">
              <div className="row g-3">
                <div
                  className="col-12 col-md-6"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    setSelectedState("");
                    setSelectedLga("");
                    setActiveMenu(
                      activeMenu === "location" && !selectedState
                        ? ""
                        : "location",
                    );
                  }}
                >
                  <label className="form-label text-secondary small fw-semibold mb-1">
                    State
                  </label>
                  <div
                    className="form-select px-3 py-2.5 border-light-subtle text-secondary d-flex align-items-center"
                    style={{ borderRadius: "12px", fontSize: "14px" }}
                  >
                    {selectedState || "Select State"}
                  </div>
                </div>

                <div
                  className="col-12 col-md-6"
                  style={{
                    cursor: selectedState ? "pointer" : "not-allowed",
                    opacity: selectedState ? 1 : 0.6,
                  }}
                  onClick={() => {
                    if (selectedState) {
                      setActiveMenu(
                        activeMenu === "location" && selectedState
                          ? ""
                          : "location",
                      );
                    }
                  }}
                >
                  <label className="form-label text-secondary small fw-semibold mb-1">
                    Local Government (LGA)
                  </label>
                  <div
                    className="form-select px-3 py-2.5 border-light-subtle text-secondary d-flex align-items-center"
                    style={{ borderRadius: "12px", fontSize: "14px" }}
                  >
                    {selectedLga || "Select LGA"}
                  </div>
                </div>
              </div>

              {activeMenu === "location" && (
                <div
                  className="position-absolute start-0 top-100 w-100 bg-white border shadow-sm p-4 mt-2"
                  style={{ borderRadius: "20px", zIndex: 99 }}
                >
                  <div className="d-flex align-items-start justify-content-between mb-3">
                    <div>
                      <h4
                        className="h6 fw-bold mb-1"
                        style={{ color: "#0f172a" }}
                      >
                        {!selectedState
                          ? "Choose a Region/State"
                          : "Choose a Local Government (LGA)"}
                      </h4>
                      {selectedState && (
                        <button
                          type="button"
                          className="btn btn-link p-0 text-decoration-none small text-success fw-semibold"
                          style={{ fontSize: "12px" }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedState("");
                            setSelectedLga("");
                          }}
                        >
                          ← Back to States
                        </button>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenu("");
                      }}
                      className="btn border-0 p-1 text-secondary lh-1"
                      style={{ fontSize: "18px" }}
                    >
                      ✕
                    </button>
                  </div>

                  <div
                    className="row g-2"
                    style={{ maxHeight: "230px", overflowY: "auto" }}
                  >
                    {!selectedState
                      ? Object.keys(NIGERIA_LOCATIONS).map((st) => (
                          <div key={st} className="col-6 col-md-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedState(st);
                                setSelectedLga("");
                              }}
                              className="btn btn-light w-100 text-start text-truncate py-2 px-3 border-0 bg-light-subtle fw-medium text-dark"
                              style={{ fontSize: "13px", borderRadius: "8px" }}
                            >
                              {st}
                            </button>
                          </div>
                        ))
                      : NIGERIA_LOCATIONS[selectedState].map((lga) => (
                          <div key={lga} className="col-6 col-md-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedLga(lga);
                                setActiveMenu("");
                              }}
                              className="btn btn-light w-100 text-start text-truncate py-2 px-3 border border-light-subtle bg-white text-secondary"
                              style={{ fontSize: "13px", borderRadius: "8px" }}
                            >
                              {lga}
                            </button>
                          </div>
                        ))}
                  </div>
                </div>
              )}
            </div>
            {/* ======================================================== */}
            {/* 🔓 REVEAL EXPANSION LAYER UNLOCKED                       */}
            {/* ======================================================== */}
            {isGatewayUnlocked && (
              <div className="mt-4 pt-4 border-top border-light-subtle">
                {selectedSubCategory === "Spares & Car Care" && (
                  <SparePartsFields />
                )}

                {/* 🚗 UPGRADED AUTOMOBILE CUSTOM SPECIFICATION TRACKS */}
                {selectedSubCategory === "Automobiles" && (
                  <div
                    className="mb-4 p-4 border border-light-subtle"
                    style={{ borderRadius: "20px", backgroundColor: "#f8fafc" }}
                  >
                    <h5 className="h6 fw-bold mb-3 text-dark">
                      🚘 Vehicle Technical Specifications
                    </h5>

                    {/* 1. Make Dropdown & Model Input Line */}
                    <div className="row g-3 mb-3">
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Car Make / Brand
                        </label>
                        <select
                          value={carBrand}
                          onChange={(e) => setCarBrand(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{
                            borderRadius: "8px",
                            fontSize: "13px",
                            minHeight: "42px",
                          }}
                        >
                          <option value="">Select Brand</option>
                          {[
                            "Acura",
                            "Audi",
                            "BMW",
                            "Chevrolet",
                            "Ford",
                            "GAC",
                            "Innoson",
                            "Honda",
                            "Hyundai",
                            "Infiniti",
                            "Kia",
                            "Land Rover",
                            "Lexus",
                            "Mazda",
                            "Mercedes-Benz",
                            "Mitsubishi",
                            "Nissan",
                            "Peugeot",
                            "Porsche",
                            "Suzuki",
                            "Toyota",
                            "Volkswagen",
                            "Volvo",
                            "Other",
                          ].map((b) => (
                            <option key={b} value={b}>
                              {b}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Car Model
                        </label>
                        <input
                          type="text"
                          value={carModel}
                          onChange={(e) => setCarModel(e.target.value)}
                          placeholder="e.g. Camry, Corolla, C300, ES350"
                          className="form-control px-3 py-2 border-light-subtle"
                          style={{
                            borderRadius: "8px",
                            fontSize: "13px",
                            minHeight: "42px",
                          }}
                        />
                      </div>
                    </div>

                    {/* Conditional input if brand choice is "Other" */}
                    {carBrand === "Other" && (
                      <div className="mb-3">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Specify Brand Name
                        </label>
                        <input
                          type="text"
                          value={customBrand}
                          onChange={(e) => setCustomBrand(e.target.value)}
                          placeholder="Enter car manufacturer name"
                          className="form-control px-3 py-2 border-light-subtle"
                          style={{ borderRadius: "10px", fontSize: "13px" }}
                        />
                      </div>
                    )}

                    {/* 2. Mileage Field & Year Select Row */}
                    <div className="row g-3 mb-3">
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Current Mileage (km)
                        </label>
                        <div className="input-group">
                          <input
                            type="number"
                            min={0}
                            value={carMileage}
                            onChange={(e) => setCarMileage(e.target.value)}
                            placeholder="e.g. 75000"
                            className="form-control px-3 py-2 border-light-subtle"
                            style={{
                              borderTopLeftRadius: "10px",
                              borderBottomLeftRadius: "10px",
                              fontSize: "13px",
                            }}
                          />
                          <span
                            className="input-group-text bg-light border-light-subtle text-muted small"
                            style={{
                              borderTopRightRadius: "10px",
                              borderBottomRightRadius: "10px",
                            }}
                          >
                            km
                          </span>
                        </div>
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Year of Manufacture
                        </label>
                        <select
                          value={carYear}
                          onChange={(e) => setCarYear(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{ borderRadius: "10px", fontSize: "13px" }}
                        >
                          <option value="">Select Year</option>
                          {Array.from({ length: 27 }, (_, i) => 2026 - i).map(
                            (yr) => (
                              <option key={yr} value={yr}>
                                {yr}
                              </option>
                            ),
                          )}
                        </select>
                      </div>
                    </div>

                    {/* 3. Chassis Number VIN Row */}
                    <div className="mb-3">
                      <label className="form-label text-secondary small fw-semibold mb-1">
                        Chassis Number / VIN (17 Characters)
                      </label>
                      <input
                        type="text"
                        value={carVin}
                        onChange={(e) =>
                          setCarVin(e.target.value.toUpperCase())
                        }
                        maxLength={17}
                        placeholder="Enter the 17-digit chassis code"
                        className="form-control px-3 py-2 border-light-subtle font-monospace text-uppercase"
                        style={{
                          borderRadius: "10px",
                          fontSize: "13px",
                          letterSpacing: "0.5px",
                        }}
                      />
                    </div>

                    {/* 4. Four Transmission Variations & Fuel Layouts */}
                    <div className="row g-3 mb-3">
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Transmission
                        </label>
                        <select
                          value={carTransmission}
                          onChange={(e) => setCarTransmission(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{ borderRadius: "10px", fontSize: "13px" }}
                        >
                          <option value="">Select Transmission</option>
                          <option value="Automatic">Automatic</option>
                          <option value="Manual">Manual</option>
                          <option value="CVT">
                            CVT (Continuously Variable)
                          </option>
                          <option value="Semi-Automatic">
                            Semi-Automatic / Automated
                          </option>
                        </select>
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Fuel Configuration
                        </label>
                        <select
                          value={carFuel}
                          onChange={(e) => setCarFuel(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{ borderRadius: "10px", fontSize: "13px" }}
                        >
                          <option value="">Select Fuel Type</option>
                          <option value="Petrol">Petrol</option>
                          <option value="Diesel">Diesel</option>
                          <option value="Hybrid">Hybrid</option>
                          <option value="Electric">Fully Electric (EV)</option>
                        </select>
                      </div>
                    </div>

                    {/* 5. Cylinders, Interior Material, and Exterior Color */}
                    <div className="row g-3 mb-3">
                      {/* Engine Cylinders */}
                      <div className="col-12 col-md-4">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Engine Cylinders
                        </label>

                        <select
                          value={carCylinders}
                          onChange={(e) => setCarCylinders(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{
                            borderRadius: "8px",
                            fontSize: "13px",
                            minHeight: "42px",
                          }}
                        >
                          <option value="">Select Cylinders</option>
                          <option value="3-Cylinder">3-Cylinder</option>
                          <option value="4-Cylinder">4-Cylinder (I4)</option>
                          <option value="6-Cylinder">6-Cylinder (V6)</option>
                          <option value="8-Cylinder">8-Cylinder (V8)</option>
                          <option value="Electric">
                            Electric (No Cylinders)
                          </option>
                        </select>
                      </div>

                      {/* Exterior Color */}
                      <div className="col-12 col-md-4">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Exterior Color
                        </label>

                        <select
                          value={carColor}
                          onChange={(e) => setCarColor(e.target.value)}
                          className="form-select px-3 py-2 border-light-subtle text-secondary"
                          style={{ borderRadius: "10px", fontSize: "13px" }}
                        >
                          <option value="">Select Color</option>

                          {[
                            "Black",
                            "White",
                            "Silver",
                            "Gray",
                            "Blue",
                            "Red",
                            "Gold",
                            "Wine",
                            "Green",
                            "Other",
                          ].map((clr) => (
                            <option key={clr} value={clr}>
                              {clr}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Interior Material */}
                      <div className="col-12 col-md-4">
                        <label className="form-label text-secondary small fw-semibold mb-1">
                          Interior Material
                        </label>

                        <div
                          className="d-flex gap-2"
                          style={{ height: "38px" }}
                        >
                          {["Leather", "Fabric"].map((mat) => (
                            <button
                              key={mat}
                              type="button"
                              onClick={() => setCarInterior(mat)}
                              className={`btn btn-sm w-50 fw-semibold ${
                                carInterior === mat
                                  ? "btn-dark text-white"
                                  : "btn-white text-secondary border bg-white"
                              }`}
                              style={{
                                borderRadius: "10px",
                                fontSize: "12px",
                              }}
                            >
                              {mat}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* 6. Multi-Select Checklist Block Grid */}
                    <div className="mb-4">
                      <label className="form-label text-secondary small fw-semibold mb-2">
                        Key Vehicle Features (Select Multiple)
                      </label>

                      <div className="row g-2">
                        {[
                          { id: "airbags", label: "🛡️ Airbags System" },
                          { id: "camera", label: "📹 Reverse Camera" },
                          { id: "screen", label: "🖥️ Android Display / Nav" },
                          { id: "sunroof", label: "☀️ Sunroof / Panoramic" },
                          { id: "rims", label: "🛞 Premium Alloy Rims" },
                          { id: "pushstart", label: "🔌 Keyless Push Start" },
                          { id: "steering", label: "🎵 Steering Controls" },
                        ].map((feat) => {
                          const active = carFeatures.includes(feat.id);

                          return (
                            <div key={feat.id} className="col-12 col-md-6">
                              <button
                                type="button"
                                onClick={() => toggleFeature(feat.id)}
                                className={`btn btn-sm w-100 py-2 text-start text-truncate fw-medium ${
                                  active
                                    ? "btn-dark text-white"
                                    : "btn-white text-secondary border bg-white"
                                }`}
                                style={{
                                  borderRadius: "10px",
                                  fontSize: "12px",
                                }}
                              >
                                <span className="me-2">
                                  {active ? "✓" : "+"}
                                </span>

                                {feat.label}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* 7. Swap Availability Switch Field */}
                    <div className="mb-2">
                      <label className="form-label text-secondary small fw-semibold mb-2">
                        Available for Swap?
                      </label>

                      <div className="d-flex gap-2">
                        {["YES", "NO"].map((ans) => (
                          <button
                            key={ans}
                            type="button"
                            onClick={() => setCarAvailableForSwap(ans)}
                            className={`btn btn-sm w-50 py-2 fw-semibold ${
                              carAvailableForSwap === ans
                                ? "btn-success text-white border-success"
                                : "btn-white text-secondary border bg-white"
                            }`}
                            style={{
                              borderRadius: "10px",
                              fontSize: "12px",
                            }}
                          >
                            {ans === "YES"
                              ? "Yes (Accepts Swap)"
                              : "No (Cash Only)"}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <section
                  className="p-4 border border-light-subtle"
                  style={{ borderRadius: "20px", backgroundColor: "#f8fafc" }}
                  aria-labelledby="ad-details-heading"
                >
                  <h5
                    id="ad-details-heading"
                    className="h6 fw-bold mb-3 text-dark"
                  >
                    Ad Details
                  </h5>
                  <div className="mb-3">
                    <label
                      htmlFor="ad-title"
                      className="form-label text-secondary small fw-semibold mb-1"
                    >
                      Title
                    </label>
                    <input
                      id="ad-title"
                      name="title"
                      required
                      placeholder={
                        selectedSubCategory === "Spares & Car Care"
                          ? "e.g. Toyota Camry replacement headlights"
                          : "e.g. Toyota Camry 2020"
                      }
                      className="form-control px-3 py-2 border-light-subtle"
                      style={{
                        borderRadius: "8px",
                        fontSize: "13px",
                        minHeight: "42px",
                      }}
                    />
                  </div>
                  <div className="row g-3 mb-3">
                    <div className="col-12 col-md-6">
                      <label
                        htmlFor="ad-price"
                        className="form-label text-secondary small fw-semibold mb-1"
                      >
                        Price (₦)
                      </label>
                      <input
                        id="ad-price"
                        name="price"
                        type="number"
                        min={0}
                        step={1}
                        required
                        className="form-control px-3 py-2 border-light-subtle no-number-arrows"
                        style={{
                          borderRadius: "8px",
                          fontSize: "13px",
                          minHeight: "42px",
                        }}
                      />
                    </div>
                    <div className="col-12 col-md-6">
                      <StyledSelect
                        key={selectedSubCategory}
                        id="ad-condition"
                        name="condition"
                        label="Condition"
                        value={condition}
                        options={
                          selectedSubCategory === "Spares & Car Care"
                            ? ["Used", "New", "Refurbished"]
                            : ["Used", "New"]
                        }
                        placeholder="Select Condition"
                        onChange={setCondition}
                      />
                    </div>
                  </div>
                  <div className="mb-3">
                    <label
                      htmlFor="ad-photo"
                      className="form-label text-secondary small fw-semibold mb-1"
                    >
                      Photos (3–10 images)
                    </label>
                    <input
                      id="ad-photo"
                      name="images"
                      type="file"
                      accept="image/*"
                      multiple
                      required
                      minLength={3}
                      className="form-control px-3 py-2 border-light-subtle"
                      style={{
                        borderRadius: "8px",
                        fontSize: "13px",
                        minHeight: "42px",
                      }}
                      onChange={(event) => {
                        const count = event.target.files?.length ?? 0;
                        if (count > 10)
                          event.target.setCustomValidity(
                            "You can upload up to 10 images.",
                          );
                        else if (count < 3)
                          event.target.setCustomValidity(
                            "Please upload at least 3 images.",
                          );
                        else event.target.setCustomValidity("");
                      }}
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      htmlFor="ad-description"
                      className="form-label text-secondary small fw-semibold mb-1"
                    >
                      Description
                    </label>
                    <textarea
                      id="ad-description"
                      name="description"
                      required
                      rows={5}
                      className="form-control px-3 py-2 border-light-subtle"
                      style={{
                        borderRadius: "8px",
                        fontSize: "13px",
                        minHeight: "42px",
                      }}
                    />
                  </div>
                  {error && (
                    <div role="alert" className="alert alert-danger">
                      {error}
                    </div>
                  )}
                  <button
                    type="submit"
                    disabled={pending}
                    className="btn btn-sq text-white w-100 fw-semibold py-2"
                    style={{
                      borderRadius: "8px",
                      fontSize: "13px",
                      minHeight: "42px",
                    }}
                  >
                    {pending ? "Posting…" : "Post ad"}
                  </button>
                </section>
              </div>
            )}
          </div>
        </div>
      </div>
    </form>
  );
}

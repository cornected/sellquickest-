// Option labels checked against https://jiji.ng/car-parts-and-accessories
// and public listings on 2026-09-15. Subtypes are the verified initial selection.
export const PART_TYPES: Record<string, string[]> = {
  "Apparel & Protective Gear": ["Other"],
  "Audio Parts": ["Audio Accessories", "Crossovers", "Media Players", "Other"],
  "Brakes, Suspension & Steering": ["Air Suspension Components", "Ball Joints & Components", "Brake Discs, Pads & Calipers", "Brake Drums, Shoes & Components", "Brake Master Cylinders, Boosters & Components", "Coil Springs & Components", "Control Arms, Thrust Arms & Components", "Lowering, Leveling & Lifting Kits", "Parking Brakes, ABS & Other Components", "Shocks, Struts & Components", "Steering Systems & Components", "Suspension Links, Rods, Bars & Components", "Suspension System Components", "Tie Rods, Steering Racks, Gearboxes & Components", "Other"],
  "Car Care": ["Cleaning Spray", "Tire Care", "Vehicle Washing Accessories", "Other"],
  "Engine & Drivetrain": ["Complete Engines", "Engine & Transmission Assemblies", "Starters, Batteries & Components", "Other"],
  "Exterior Accessories": ["Bumpers & Parts", "Fenders", "Other"],
  "Headlights & Lighting": ["Headlights, Components & Accessories", "Other"],
  "Interior Accessories": ["Consoles", "Seat Covers", "Other"],
  "Motorcycle Parts": ["Protection Parts", "Other"],
  "Oils & Fluids": ["Automotive Lubricants", "Brake Fluids", "Compressor Oils", "Flushing Oils", "Motor Oils", "Transmission Oils", "Other"],
  "Safety & Security": ["Steering Wheel Locks", "Other"],
  "Watercraft & Boat Parts": ["Boat & Engine Covers", "Complete Engines & Parts", "Electrical Systems", "Propellers & Shafts", "Pumps & Plumbing", "Water Tanks", "Other"],
  "Wheels & Parts": ["Jacks", "Rims", "Spare Tire Accessories", "Tire & Wheel Care", "Tires", "Wheel Balancer", "Wheels", "Wheels Covers, Caps & Simulators", "Other"],
  "Other": ["Other"],
};

export const PART_MAKES = ["Acura", "Alfa Romeo", "Ashok Leyland", "Aston Martin", "Audi", "Bajaj", "BAW", "Bentley", "BMW", "Brilliance", "Buick", "Cadillac", "Changan", "Chery", "Chevrolet", "Chrysler", "Citroen", "Daewoo", "DAF", "Daihatsu", "Datsun", "Denstar", "Dentools", "DGM", "Dodge", "Dongfeng", "Drom Power", "Ducati", "Ferrari", "Fiat", "Ford", "Foton", "GAC", "Geely", "GMC", "Great Wall", "Haojue", "Honda", "Hummer", "Hyundai", "Infiniti", "Isuzu", "Iveco", "IVM", "JAC", "Jaguar", "Jeep", "Jincheng", "JMC", "Joylong", "Kawasaki", "Kenworth", "Kia", "Kymco", "Lamborghini", "Land Rover", "Lexus", "Lifan", "Lincoln", "Linglong", "Mack", "Mahindra", "MAN", "Maserati", "Mazda", "Mercedes-Benz", "Mercury", "MG", "Mini", "Mitsubishi", "Morris", "Nissan", "Nord", "Opel", "Peugeot", "Pontiac", "Porsche", "Qlink", "Renault", "Rolls-Royce", "Rover", "Saab", "Samsung", "Sanya", "Saturn", "Scania", "Scion", "Seat", "Senke", "Shacman", "Sinotruk", "Skoda", "Smart", "SsangYong", "Steyr", "Subaru", "Suzuki", "T-King", "Tata", "Toyota", "Volkswagen", "Volvo", "Yamaha", "ZX Auto", "Other Make"];

export type SpareDetails = { make: string; model: string; type: string; subtype: string };

export function parseSpareDetails(value: unknown): SpareDetails | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const fields = value as Record<string, unknown>;
  const clean = (key: string) => typeof fields[key] === "string" ? fields[key].trim() : "";
  const result = { make: clean("make"), model: clean("model"), type: clean("type"), subtype: clean("subtype") };
  if (!PART_MAKES.includes(result.make) || !result.model || result.model.length > 100 ||
      !Object.hasOwn(PART_TYPES, result.type) || !PART_TYPES[result.type].includes(result.subtype)) return null;
  return result;
}
